#!/bin/bash

bash helper_scripts/graph1.sh
bash helper_scripts/graph2.sh
bash helper_scripts/graph4.sh
bash helper_scripts/graph6.sh
bash helper_scripts/graph9.sh