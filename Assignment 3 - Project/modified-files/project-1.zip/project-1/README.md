# CS607 Assignment 3 (Project)

- Name: B Siddharth Prabhu
- Roll Number: 200010003

<details>
<summary></summary>
> **Note:** We were asked to put our 'team member names' and 'UW net IDs' here. However, this assignment is individual work, and UW net ID refers to the ID number of a student at the University of Washington. This is not required. So, the above must suffice.
</details>

---

### Directory Structure
- ```pox/``` contains the code for part 2, in ```a1part2controller.py```.
- ```topos/``` contains code that defines different topology, with ```part1.py``` being used in part 1, and ```part2.py``` being used in part 2.
- The ```screenshots/``` folder is self-explanatory.
- ```CS607_Report_A3.pdf``` contains a pdf with all screenshots (and a few extra ones near the end), as such was requested in one of the questions of the worksheet.

